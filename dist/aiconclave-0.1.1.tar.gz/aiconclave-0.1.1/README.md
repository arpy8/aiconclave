# aiconclave
This package contains the python scripts for the AI conclave exhibition 2023.

- Command Prompt:
```
pip install aiconclave && aiconclave
```
- Powershell:
```
pip install aiconclave ; aiconclave
```