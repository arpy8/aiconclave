import streamlit as st
print(st._server.port)